

<?php $__env->startSection('title', $task->title); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-4xl mx-auto">
        <div class="mb-6 flex justify-between items-center">
            <h2 class="text-2xl font-semibold text-gray-900"><?php echo e($task->title); ?></h2>
            <div class="flex items-center space-x-4">
                <?php if(auth()->user()->isSuperAdmin() && !$task->isCompleted()): ?>
                    <form action="<?php echo e(route('tasks.complete', $task)); ?>" method="POST" class="inline">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600"
                            onclick="return confirm('Are you sure you want to mark this task as completed?')">
                            Mark as Completed
                        </button>
                    </form>
                <?php endif; ?>
                <a href="<?php echo e(route('tasks.index')); ?>" class="text-gray-600 hover:text-gray-900">
                    Back to Tasks
                </a>
            </div>
        </div>

        <?php if(session('success')): ?>
            <div class="mb-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
                <span class="block sm:inline"><?php echo e(session('success')); ?></span>
            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="mb-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                <span class="block sm:inline"><?php echo e(session('error')); ?></span>
            </div>
        <?php endif; ?>

        <div class="bg-white shadow-sm rounded-lg overflow-hidden mb-6">
            <div class="p-6">
                <div class="mb-6">
                    <h3 class="text-lg font-medium text-gray-900 mb-2">Description</h3>
                    <p class="text-gray-700 whitespace-pre-wrap"><?php echo e($task->description); ?></p>
                </div>

                <div class="grid grid-cols-2 gap-6">
                    <div>
                        <h4 class="text-sm font-medium text-gray-500">Status</h4>
                        <p class="mt-1">
                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                <?php if($task->status === 'completed'): ?> bg-green-100 text-green-800
                                <?php elseif($task->status === 'in_progress'): ?> bg-blue-100 text-blue-800
                                <?php else: ?> bg-gray-100 text-gray-800 <?php endif; ?>">
                                <?php echo e(ucfirst(str_replace('_', ' ', $task->status))); ?>

                            </span>
                        </p>
                    </div>
                    <div>
                        <h4 class="text-sm font-medium text-gray-500">Created By</h4>
                        <p class="mt-1 text-gray-900"><?php echo e($task->creator->name); ?></p>
                    </div>
                    <div>
                        <h4 class="text-sm font-medium text-gray-500">Created At</h4>
                        <p class="mt-1 text-gray-900"><?php echo e($task->created_at->format('M d, Y H:i')); ?></p>
                    </div>
                    <div>
                        <h4 class="text-sm font-medium text-gray-500">Assigned To</h4>
                        <p class="mt-1 text-gray-900"><?php echo e($task->assignedUsers->pluck('name')->join(', ')); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="bg-white shadow-sm rounded-lg overflow-hidden">
            <div class="p-6">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Comments</h3>

                <?php if(!$task->isCompleted()): ?>
                    <form action="<?php echo e(route('tasks.comments.store', $task)); ?>" method="POST" enctype="multipart/form-data" class="mb-6">
                        <?php echo csrf_field(); ?>
                        <div class="mb-4">
                            <label for="content" class="block text-sm font-medium text-gray-700">Add a comment</label>
                            <textarea name="content" id="content" rows="3"
                                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                                required></textarea>
                        </div>
                        <div class="mb-4">
                            <label for="attachment" class="block text-sm font-medium text-gray-700">Attachment (optional)</label>
                            <input type="file" name="attachment" id="attachment"
                                class="mt-1 block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100">
                            <p class="mt-1 text-sm text-gray-500">Allowed file types: PNG, JPG, PDF, DOC, DOCX (max 10MB)</p>
                        </div>
                        <div class="flex justify-end">
                            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600">
                                Add Comment
                            </button>
                        </div>
                    </form>
                <?php endif; ?>

                <div class="space-y-6">
                    <?php $__empty_1 = true; $__currentLoopData = $task->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="flex space-x-4">
                            <div class="flex-shrink-0">
                                <img class="h-10 w-10 rounded-full" src="<?php echo e($comment->user->avatar ?? 'https://ui-avatars.com/api/?name='.urlencode($comment->user->name)); ?>" alt="">
                            </div>
                            <div class="flex-grow">
                                <div class="flex items-center justify-between">
                                    <h4 class="text-sm font-medium text-gray-900"><?php echo e($comment->user->name); ?></h4>
                                    <p class="text-sm text-gray-500"><?php echo e($comment->created_at->diffForHumans()); ?></p>
                                </div>
                                <div class="mt-1 text-sm text-gray-700">
                                    <p class="whitespace-pre-wrap"><?php echo e($comment->content); ?></p>
                                    <?php if($comment->hasAttachment()): ?>
                                        <div class="mt-2">
                                            <a href="<?php echo e(route('tasks.comments.download', [$task, $comment])); ?>"
                                                class="inline-flex items-center text-sm text-blue-600 hover:text-blue-500">
                                                <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                        d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z">
                                                    </path>
                                                </svg>
                                                <?php echo e($comment->attachment_name); ?>

                                            </a>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-gray-500 text-center">No comments yet.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\taski\resources\views/tasks/show.blade.php ENDPATH**/ ?>